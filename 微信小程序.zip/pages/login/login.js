// pages/login/login.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        token: '',
        projectId: '',
        stId: ''
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        console.log(options)
        this.data.token = options.token
        this.data.projectId = options.projectId
        console.log(this.data.token)
    },

    sign() {
      let that = this
        wx.getLocation({
            type: 'wgs84',
            success(res) {
                const latitude = res.latitude
                const longitude = res.longitude
                const speed = res.speed
                const accuracy = res.accuracy
                console.log(latitude, longitude, speed, accuracy)
                wx.request({
                    url: 'http://192.168.137.1:8080/user/sign',
                    method: 'POST',
                    data: {
                        projectId: that.data.projectId,
                        stId: that.data.stId,
                        latitude: latitude,
                        longitude: longitude
                    },
                    header: {
                        'token': that.data.token
                    },
                  success(re) {
                        console.log(re)
                        if (re.data.code === 200) {
                            wx.showToast({
                                title: re.data.msg,
                                icon: 'success',
                                duration: 2000
                            })
                        } else {
                            wx.showToast({
                                title: re.data.msg,
                                icon: 'none',
                                duration: 2000
                            })
                        }
                  }

                })
            }

        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    },
    input(res) {
        console.log(res)
        this.data.stId = res.detail.value
        console.log(this.data.stId)
    }

})
