// index.js

Page({
    data: {},


    scanCodeEvent: function () {
        var that = this;
        wx.scanCode({
            onlyFromCamera: true,// 只允许从相机扫码
            success(sc) {
                console.log(sc)
                let result = JSON.parse(sc.result)
                console.log(result)
                wx.login({
                    success: (res) => {
                        console.log(res)
                        var wxCode = res.code;
                        wx.request({
                            url: 'http://192.168.137.1:8080/user/getToken',
                            method: 'POST',
                            data: {
                              code: result.Code,
                                projectId: result.projectId,
                                wxCode: wxCode,
                            },
                            success(suc){
                                console.log(suc)
                                if (suc.data.code == 200) {
                                    wx.redirectTo(
                                        {
                                            url: '/pages/login/login?token=' + suc.data.token + '&projectId=' + result.projectId
                                        }
                                    )
                                }
                            }
                        })

                    },
                })
            }
        })
    },

})
