<script setup>

import {reactive} from "vue";
import {ElMessage} from "element-plus";
import {LoginAPI} from "@/api/admin/loginApi";
import {RegisterApi} from "@/api/admin/RegisterApi";
import router from "@/router";


const userLoginForm = reactive({
  username: "",
  password: ""
})

const userRegisterForm = reactive({
  username: "",
  password: "",
  phone: "",
  email: ""
})
let STlogin = reactive({
  login: true
})

function toRegister() {
  STlogin.login = !STlogin.login
}

function login() {
  console.log(userLoginForm)
  LoginAPI(userLoginForm).then(res => {
    console.log(res)
    if (res.data.code === 200) {
      localStorage.setItem('token', res.data.token)
      ElMessage.success('登录成功')
      // this.$router.push('/admin-index')

      router.push('/admin-index')
    } else {
      ElMessage.error('账号或密码错误，请检查后重试')
    }
  })
}

function register() {
  RegisterApi(userRegisterForm).then(res => {
    console.log(res)
    if (res.data.code === 200) {
      ElMessage.success('注册成功')
      STlogin.login = !STlogin.login
    } else {
      ElMessage.error('注册失败')
    }
  })
}

function forget() {
  ElMessage('忘记密码请联系系统管理员')
}

function reback() {
  STlogin.login = !STlogin.login
}

</script>

<template>
  <div v-show="STlogin.login">
    <h2>欢迎登录</h2>
    <form class="login" action="">
      <input type="text" v-model="userLoginForm.username" placeholder="请输入账号" autocomplete="off">
      <input type="password" v-model="userLoginForm.password" placeholder="请输入密码" autocomplete="off">
    </form>
    <div class="remember">
      <a @click="forget">忘记密码</a>
      &emsp;
      <a @click="toRegister">注册账号</a>
    </div>
    <div id="btn">
      <button class="loginbtn" @click="login">登陆</button>
    </div>
  </div>
  <div v-show="!STlogin.login">
    <h2>注册账号</h2>
    <form class="login" action="">
      <input type="text" v-model="userRegisterForm.username" placeholder="账号">
      <input type="password" v-model="userRegisterForm.password" placeholder="请输入密码">
      <input type="text" v-model="userRegisterForm.phone" placeholder="请输入手机号">
      <input type="text" v-model="userRegisterForm.email" placeholder="请输入邮箱">
    </form>
    <div id="btn">
      <button class="loginbtn" @click="reback">返回</button>
      <button class="loginbtn" @click="register">注册</button>
    </div>
  </div>
</template>

<style scoped lang="less">
h2 {
  margin-bottom: 5px;
}

.login {
  input {
    width: 80%;
    height: 45px;
    margin-top: 10px;
    border: 1px solid white;
    background-color: rgba(255, 255, 255, 0.5);
    border-radius: 10px;
    font-size: inherit;
    padding-left: 20px;
    outline: none;
  }
}


.remember {
  float: right;
  height: 26px;
  text-align: center;
  font-size: 1rem;
  position: relative;
}

.loginbtn {
  width: 100%;
  height: 35px;
  margin-top: 10px;
  border-radius: 10px;
  background-color: rgba(207, 38, 38, 0.8);
}
</style>
