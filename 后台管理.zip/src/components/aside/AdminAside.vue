<template>
  <el-menu
      default-active="1"
      class="el-menu-vertical-demo"
      :collapse="isCollapse"
      @open="handleOpen"
      @close="handleClose"
  >
    <el-menu-item @click="setroute('/admin-index')" index="1">
      <el-icon>
        <HomeFilled/>
      </el-icon>
      <template #title><span>首页</span></template>
    </el-menu-item>

    <el-menu-item @click="setroute('/admin-search')" index="2">
      <el-icon><DataAnalysis/></el-icon>
      <template #title><span>任务总览</span></template>
    </el-menu-item>

    <el-menu-item @click="setroute('/admin-GameSet')" index="3">
      <el-icon><DataAnalysis/></el-icon>
      <template #title><span>任务管理</span></template>
    </el-menu-item>


    <el-menu-item @click="setroute('/admin-MemberSearch')" index="4">
      <el-icon><DataAnalysis/></el-icon>
      <template #title><span>学生管理</span></template>
    </el-menu-item>



  </el-menu>

  <el-main>
    <router-view></router-view>
  </el-main>

</template>

<script setup>

//设置跳转路由
import { useRouter } from 'vue-router'
const route = useRouter();
function setroute($rout)
{

  route.push($rout);
}

</script>
