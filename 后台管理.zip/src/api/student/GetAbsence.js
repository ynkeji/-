import request from '@/util/request';

export const GetAbsence = () => {
    return request({
        url: '/admin/getAbsenceList',
        method: 'GET',
    })
}
