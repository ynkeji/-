import request from '@/util/request';

export const updataStudent = (data) => {
    return request({
        url: '/admin/updateStudent',
        method: 'POST',
        data
    })
}
