import request from '@/util/request';

export const getItemList = (data) => {
    return request({
        url: 'admin/getProjectInfo?stId=' + data,
        method: 'GET',
    })
}
