import request from '@/util/request';

export const getStudent = () => {
    return request({
        url: '/admin/getStudent',
        method: 'GET',
    })
}
