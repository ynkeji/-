import request from '@/util/request';

export const deleteStudent = (stId) => {
    return request({
        url: '/admin/deleteStudent?stId=' + stId,
        method: 'GET',
    })
}
