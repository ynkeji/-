import request from '@/util/request';


export const addStudent = (data) => {
    return request({
        url: '/admin/addStudent',
        method: 'POST',
        data
    })
}
