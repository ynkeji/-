import request from "@/util/request";

export const RegisterApi = (data) => {
    return request({
        url: '/admin/register',
        method: 'POST',
        data
    })
}
