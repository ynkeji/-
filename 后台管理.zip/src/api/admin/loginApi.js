import request from "@/util/request";

export const LoginAPI = (data) => {
    return request({
        url: '/admin/login',
        method: 'POST',
        data
    })
}
