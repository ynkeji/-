import request from "@/util/request";

export const AdminUserInfo = () => {
    return request({
        url: '/admin/userInfo',
        method: 'GET',
    })
}
