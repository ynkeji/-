import request from '@/util/request';

export const updateItem = (data) => {
    return request({
        url: '/admin/updateItem',
        method: 'POST',
        data
    })
}
