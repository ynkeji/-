

import request from '@/util/request'

export const deleteItem = (id) => {
    return request({
        url: '/admin/deleteItem?id=' + id,
        method: 'GET',
    })
}
