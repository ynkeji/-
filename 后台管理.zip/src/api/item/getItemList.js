import request from "@/util/request";

export const ItemList = () => {
    return request({
        url: '/admin/getProject',
        method: 'GET',
    })
}
