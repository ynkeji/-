import request from '@/util/request';

export const getSignDetail = (data) => {
    return request({
        url: '/admin/getSignList?projectId=' + data,
        method: 'GET',
    })
}
