import request from '@/util/request'

export const ItemView = () => {
    return request({
        url: '/admin/ItemView',
        method: 'GET',
    })
}
