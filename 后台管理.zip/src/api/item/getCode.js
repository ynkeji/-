import request from '@/util/request';

export const   qrCode = (data) => {
    return request({
        url: '/admin/QRCode?itemId=' + data,
        method: 'GET',
    })
}
