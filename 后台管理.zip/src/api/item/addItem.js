import request from "@/util/request";

export const addItem = (data) => {
    console.log(data)
    return request({
        url: '/admin/addItem',
        method: 'POST',
        data
    })
}
