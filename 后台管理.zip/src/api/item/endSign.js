import request from '@/util/request';

export const ESign = (data) => {
    return request({
        url: '/admin/endSign?itemId=' + data,
        method: 'GET',
    })
}
