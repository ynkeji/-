import request from '@/util/request';

export const startSign = (data) => {
    return request({
        url: '/admin/startSign?itemId=' + data,
        method: 'GET',
    })
}
