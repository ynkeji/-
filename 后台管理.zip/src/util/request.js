
import axios from 'axios'
import router from '@/router'
import {ElMessage} from "element-plus";
// import { ElMessage } from 'element-plus'

// const baseURL = 'https://api.longfish.site'
const baseURL = 'http://localhost:8080'
const instance = axios.create({
    baseURL,
    timeout: 100000,
    headers:{
        'Content-Type':'application/json'
    }
})

instance.interceptors.request.use(
    (config) => {
        const token = window.localStorage.getItem('token');

        // 如果有 token，就将它添加到请求头中
        if (token) {
            config.headers['token'] = token;
        }
        return config
    },
    (err) => Promise.reject(err)
)

instance.interceptors.response.use(
    (res) => {
        if (res.data.msg === "token过期") {
            console.log('token过期')
            ElMessage({ message: 'token过期', type: 'error' })
            router.push('/login')
        }
        if (res.data.code === 200) {

            return res
        }
        ElMessage({ message: res.data.msg || '服务异常', type: 'error' })

        return Promise.reject(res.data)
    },
    (err) => {

        // ElMessage({
        //     message: err.response.data.msg || '服务异常',
        //     type: 'error'
        // })
        console.log(err)
        // 401tokon失效处理
        // 返回登录页，清除用户信息
        if (err.response?.status === 401) {
            router.push('/login')
        }
        return Promise.reject(err)
    }
)

export default instance
export { baseURL }
