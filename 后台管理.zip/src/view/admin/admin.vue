<template>
  <el-container class="home_container">
    <!-- 头部区域 -->
    <el-header>
      <div>
        <img src="../../assets/logo.png" alt="" class="my-logo"/>
      </div>
      <div class="user">
        <el-text class="mx-1" type="primary">用户名:{{ username }} </el-text>
        <el-button type="primary" @click="logout">退出登录</el-button>
      </div>
    </el-header>
    <!-- 页面主体区域 -->
    <el-container style="height: 100vh">
      <myaside></myaside>
    </el-container>
  </el-container>
</template>
<script>
import myaside from '../../components/aside/AdminAside.vue';
import {getCurrentInstance, onMounted} from "vue";
import {AdminUserInfo} from "@/api/admin/AdminUserInfo";
// import api from "@/request/request";
// import router from "@/router";
// import {ElMessage} from "element-plus";

export default {

  data() {
    return {
      username:'',

    }
  },
  components: {
    myaside
  },
  methods: {
    logout() {
      localStorage.clear()  //清除缓存
      this.$router.push('/login')  //跳转到登录页面
    },

  },

  setup(){


    console.log("进入了admin界面")
    const ins = getCurrentInstance();
    onMounted(()=>{
      AdminUserInfo().then(res=>{
        console.log(res)
        ins.data.username = res.data.data.username
      })
    });
  }
}
</script>


<style lang="less" scoped>
.home_container {
  height: 100%;
}

.el-header {
  background-color: #363d40;
  // 给头部设置一下弹性布局
  display: flex;
  // 让它贴标左右对齐
  justify-content: space-between;
  // 清空图片左侧padding
  padding-left: 0;
  // 按钮居中
  align-items: center;
  // 文本颜色
  color: #fff;
  // 设置文本字体大小
  font-size: 20px;
  // 嵌套
  > div {
    // 弹性布局
    display: flex;
    // 纵向上居中对齐
    align-items: center;
    // 给文本和图片添加间距，使用类选择器
    span {
      margin-left: 15px;
    }
  }
}

.el-aside {
  background-color: #313743;

  .el-menu {
    border-right: none;
  }
}

.el-main {
  background-color: #e9edf1;

}

.iconfont {
  margin-right: 10px;
}

.toggle-button {
  // 添加背景颜色
  background-color: #4A5064;
  // 设置文本大小
  font-size: 10px;
  // 设置文本行高
  line-height: 24px;
  // 设置文本颜色
  color: #fff;
  // 设置文本居中
  text-align: center;
  // 设置文本间距
  letter-spacing: 0.2em;
  // 设置鼠标悬浮变小手效果
  cursor: pointer;
}


.my-logo {
  width: 200px;
  height: 50px;
}
</style>
