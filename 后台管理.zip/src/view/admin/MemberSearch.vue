<!--suppress ALL -->
<template>
  <div>
    <!--    本页面来源-->
    <!--    //https://blog.csdn.net/weixin_39237340/article/details/122180353-->
    <el-card style="height: 90vh">

      <!-- 用户列表区域  -->
      <el-table :data="tableData" style="width: 100%" max-height="600">
        <el-table-column prop="stId" label="学生学号" width="180"/>
        <el-table-column prop="stName" label="学生姓名" width="180"/>
        <el-table-column prop="stSex" label="性别" width="180"/>
        <el-table-column prop="stPhone" label="电话" width="180"/>
        <el-table-column prop="stEmail" label="邮箱" width="180"/>
        <el-table-column fixed="right" label="操作" width="180">
          <template v-slot="scope">
            <!--修改user信息-->
            <el-tooltip effect="light" content="修改信息" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="user_set(scope.row)"
              >
                <el-icon>
                  <Edit/>
                </el-icon>
              </el-button>
            </el-tooltip>
            <!--删除user信息按钮-->
            <el-tooltip effect="light" content="删除成员" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="user_delete(scope.row)"
              >
                <el-icon>
                  <Delete/>
                </el-icon>
              </el-button>
            </el-tooltip>

            <el-tooltip effect="light" content="报名项目" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="openSign(scope.row)"
              >
                <el-icon>
                  <Promotion/>
                </el-icon>
              </el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
    <!--添加用户弹出窗口-->
    <el-dialog v-model="dialogFormVisible" title="学生信息修改" width="500px">
      <el-form :model="RestStForm"
               :label-position="'right'">
        <el-form-item label="*学号">
          <el-input v-model="RestStForm.stId"/>
        </el-form-item>

        <el-form-item label="*姓名">
          <el-input v-model="RestStForm.stName"/>
        </el-form-item>

        <el-form-item label="*性别">
          <el-input v-model="RestStForm.stSex"/>
        </el-form-item>

        <el-form-item label="*邮箱">
          <el-input v-model="RestStForm.stEmail"/>
        </el-form-item>

        <el-form-item label="*手机号">
          <el-input v-model="RestStForm.stPhone"/>
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="RestStu = false">关闭窗口</el-button>
        <el-button type="primary" @click="setStu(RestStForm)">修改信息</el-button>
      </span>
      </template>
    </el-dialog>


    <!--修改用户弹出窗口-->
    <el-dialog v-model="RestStu" title="学生信息修改" width="500px">
      <el-form :model="RestStForm"
               :label-position="'right'">
        <el-form-item label="*学号">
          <el-input v-model="RestStForm.stId"/>
        </el-form-item>

        <el-form-item label="*姓名">
          <el-input v-model="RestStForm.stName"/>
        </el-form-item>

        <el-form-item label="*性别">
          <el-input v-model="RestStForm.stSex"/>
        </el-form-item>

        <el-form-item label="*邮箱">
          <el-input v-model="RestStForm.stEmail"/>
        </el-form-item>

        <el-form-item label="*手机号">
          <el-input v-model="RestStForm.stPhone"/>
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="RestStu = false">关闭窗口</el-button>
        <el-button type="primary" @click="setStu(RestStForm)">修改信息</el-button>
      </span>
      </template>
    </el-dialog>
    <!--添加比赛弹出窗口-->
    <el-dialog v-model="addGame" title="添加签到项目" width="500px">
      <el-form :model="form"
               :label-position="'right'">
        <el-form-item label="*项目名称">
          <el-input v-model="form.name"/>
        </el-form-item>

        <el-form-item label="*签到经度">
          <el-input v-model="form.longitude"/>
        </el-form-item>

        <el-form-item label="*签到纬度">
          <el-input v-model="form.latitude"/>
        </el-form-item>

        <el-form-item label="*签到范围(米)">
          <el-input v-model="form.area"/>
        </el-form-item>

      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="addGame = false">关闭窗口</el-button>
        <el-button type="primary" @click="setNewGame(form)">添加项目</el-button>
      </span>
      </template>
    </el-dialog>

    <!--    //查看学生签到详情-->
    <el-dialog v-model="signFormdia" title="查看详情" width="70vw">
      <el-table :data="ItemList" style="width: 100%" max-height="600">
        <el-table-column prop="projectId" label="项目编号" width="180"/>
        <el-table-column prop="name" label="项目名称" width="180"/>
        <el-table-column prop="signed" label="签到状态" width="180"/>
        <el-table-column prop="absence" label="请假状态" width="180"/>
        <el-table-column prop="late" label="迟到状态" width="180"/>
        <el-table-column prop="signTime" label="签到时间" width="180"/>
        <el-table-column prop="latitude" label="签到经度" width="180"/>
        <el-table-column prop="longitude" label="签到纬度" width="180"/>

      </el-table>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="signFormdia = false">关闭窗口</el-button>
      </span>
      </template>
    </el-dialog>
  </div>
</template>


<script>

import {ElMessage} from "element-plus";
import router from "@/router";
import {getCurrentInstance, onMounted} from "vue";
import {getStudent} from "@/api/student/getStudent";
import {deleteStudent} from "@/api/student/deleteStudent";
import {updataStudent} from "@/api/student/updataStudent";
import {ItemList} from "@/api/item/getItemList";
import {getItemList} from "@/api/student/getItemList";
export default {

  data() {
    return {
      ItemList:[],
      RestStForm: {},
      findStudentById: '',
      //添加用户表单
      form: {},
      signForm: {},
      //修改用户表单
      form_set: {},
      //添加用户窗口展示
      signFormdia: false,
      dialogFormVisible: false,
      setUserInfo: false,
      //列表项
      tableData: [],
      signOption: [],
      optionsByName: '',
      optionsByType: '',


    }
  },
  methods: {
    //添加用户事件
    add_user() {
      this.dialogFormVisible = true
    },


    //user信息修改
    user_set($row) {
      console.log($row)
      this.dialogFormVisible = true;
       this.RestStForm = {
        stId: $row.stId,
        stName: $row.stName,
        stSex: $row.stSex,
        stEmail: $row.stEmail,
        stPhone: $row.stPhone
       }
    },

    ///修改学生信息
    setStu($form) {
      let that = this
      console.log($form)
      var jsonForm = JSON.stringify($form)
      updataStudent(jsonForm).then(res => {
        console.log(res)
        getStudent().then(res => {
          console.log(res)
          that.tableData = res.data.data
        })
        this.dialogFormVisible = false;
      })
    },

    //user删除方法
    user_delete($row) {

      let that = this
      console.log($row)
      console.log($row.stId)
      deleteStudent($row.stId).then(res => {
        console.log(res)
          getStudent().then(res => {
            that.tableData = res.data.data
          })
      })
    },

    //表单验证
    validateForm($form) {
    },

    //添加user信息
    check($user) {

    },

    selectAll() {

    },

    openSign($row) {
      this.signFormdia = true
      getItemList($row.stId).then(res => {
        console.log(res)
        this.ItemList = res.data.data
      })
    },
    sign($form) {

    },
    //根据学号查询学生
    findStu($id) {

    },

    handleclear() {

    }


  },
  setup() {
    const ins = getCurrentInstance();
    onMounted(() => {
      getStudent().then(res => {
        console.log(res)
        ins.data.tableData = res.data.data
      })
    })
  }


}

</script>

<style lang="less" scoped>

</style>
