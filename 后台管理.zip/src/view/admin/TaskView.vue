<template>
  <div>
    <!--    本页面来源-->
    <!--    //https://blog.csdn.net/weixin_39237340/article/details/122180353-->
    <el-card>

      <!-- 用户列表区域  -->
      <el-table :data="task" style="width: 100%" max-height="600">\
        <el-table-column prop="id" label="项目编号" width="180"/>
        <el-table-column prop="name" label="任务名称" width="180"/>
        <el-table-column prop="sum" label="签到人数" width="180"/>
        <el-table-column prop="signCount" label="已签人数" width="180"/>
        <el-table-column prop="lateCount" label="迟到人数" width="180"/>
        <el-table-column prop="absenceCount" label="请假人数" width="180"/>
        <el-table-column fixed="right" label="Operations" width="180">
          <template v-slot="scope">
            <el-button
                link
                type="primary"
                size="default"
                @click="Detail(scope.row)"
            >
              查看详情
            </el-button>


            <el-button
                link
                type="primary"
                size="default"
                @click="st(scope.row)"
            >
              开始签到
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
    <el-dialog v-model="sign" title="开始签到" fullscreen :before-close="endSign">
      <div style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%">
        <el-image style="width: 300px; height: 300px" :src="url" :fit="fit" />
      </div>
    </el-dialog>


    <el-dialog v-model="dialogFormVisible" title="签到详情" width="70vw">
      <el-table :data="ItemDetail" height="400px">
        <el-table-column prop="stId" label="学生学号"></el-table-column>
        <el-table-column prop="stName" label="学生姓名"></el-table-column>
        <el-table-column prop="signed" label="签到状态"></el-table-column>
        <el-table-column prop="absence" label="请假状态"></el-table-column>
        <el-table-column prop="late" label="迟到状态"></el-table-column>
        <el-table-column prop="signTime" label="签到时间"></el-table-column>
        <el-table-column prop="longitude" label="签到经度"></el-table-column>
        <el-table-column prop="latitude" label="签到纬度"></el-table-column>
        <el-table-column prop="reason" label="原因"></el-table-column>
        <el-table-column fixed="right" label="操作" width="180">
          <template v-slot="scope">
            <!--删除user信息按钮-->
            <el-tooltip effect="light" content="删除成员" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="StDelete(scope)"
              >
                <el-icon>
                  <Delete/>
                </el-icon>
              </el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogFormVisible = false">关闭窗口</el-button>
      </span>
      </template>
    </el-dialog>

  </div>
</template>


<script>

import {getCurrentInstance, onMounted} from "vue";
import {ItemView} from "@/api/item/ItemView";
import {getSignDetail} from "@/api/item/SignDetail";
import {startSign} from "@/api/item/starSign";
import {qrCode} from "@/api/item/getCode";
import {ESign} from "@/api/item/endSign";

export default {

  data() {
    return {
      sign: false,
      url:"",
      loop:false,
      option: {
        name: '',
        type: ''
      },
      flag:0,
      id:0,
      ItemDetail: [],
      form: {},
      dialogFormVisible: false,
      tableData: [
        {}
      ],
      // 获取用户列表的参数对象
      task: [],
      //项目列表
      optionsByName: '',

      optionsByType: '',

    }
  },
  methods: {

    endSign(){
      console.log("关闭签到")
      ESign(this.id).then(res => {
        if (res.data.code === 200){
          this.loop = false
          clearTimeout(this.flag)
          this.sign = false
        }
      }).catch(err => {
        console.log(err)
        this.loop = false
        clearTimeout(this.flag)
        this.sign = false
      })
    },
    st(row){
      startSign(row.id).then(res => {
        if (res.data.code === 200) {
          this.id = row.id
          this.sign = true
          this.loop = true
          this.getCode(row.id)
        }
      })
    },

    getCode(id){
      if (this.loop){
        qrCode(id).then(res => {
          if (res.data.code === 200){
            this.url='data:image/png;base64,' + res.data.data
            this.flag = setTimeout(() => {
              this.getCode(id)
            }, 20000)
          }

        })
      }
      else{
        return;
      }
    },


    search() {

    },


    //open dialog
    open_dialog() {

    },

    del() {

    },

    Detail($row) {
      this.dialogFormVisible = true
      getSignDetail($row.id).then(res => {
        console.log(res)
        this.ItemDetail = res.data.data
      })
    },

    setGrade() {

    },
  },
  setup() {
    const ins = getCurrentInstance();
    onMounted(() => {
      ItemView().then(res => {
        console.log(res)
        ins.data.task = res.data.data
      })
    });
  }
}
</script>

<style lang="less" scoped>

</style>
