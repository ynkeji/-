<!--suppress ALL -->
<template>
  <div>
    <el-card>
      <!-- 项目查询框表单-->


      <!-- 用户列表区域  -->
      <el-table :data="taskList" style="width: 100%" max-height="700">
        <el-table-column prop="id" label="项目编号" width="120"/>
        <el-table-column prop="name" label="项目名称" width="180"/>
        <el-table-column prop="stidCount" label="签到人数" width="180"/>
        <el-table-column prop="longitude" label="签到经度" width="180"/>
        <el-table-column prop="latitude" label="签到纬度" width="180"/>
        <el-table-column prop="area" label="签到范围" width="180"/>
        <el-table-column fixed="right" label="操作" width="180">
          <template v-slot="scope">
            <el-tooltip effect="light" content="修改信息" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="openGameSet(scope.row)"
              >
                <el-icon>
                  <Edit/>
                </el-icon>
              </el-button>
            </el-tooltip>

            <!--            查询报名人数-->
            <el-tooltip effect="light" content="查询报名详情" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="OpenSingUpList(scope.row)"
              >
                <el-icon>
                  <Monitor/>
                </el-icon>
              </el-button>
            </el-tooltip>

            <!--删除user信息按钮-->
            <el-tooltip effect="light" content="删除成员" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="Itemdelete(scope.row)"
              >
                <el-icon>
                  <Delete/>
                </el-icon>
              </el-button>
            </el-tooltip>

          </template>
        </el-table-column>
      </el-table>

    </el-card>

    <!--学生信息修改-->
    <el-dialog v-model="RestStu" title="学生信息修改" width="500px">
      <el-form :model="RestStForm"
               :label-position="'right'">
        <el-form-item label="*学号">
          <el-input v-model="RestStForm.stId"/>
        </el-form-item>

        <el-form-item label="*姓名">
          <el-input v-model="RestStForm.stName"/>
        </el-form-item>

        <el-form-item label="*性别">
          <el-input v-model="RestStForm.stSex"/>
        </el-form-item>

        <el-form-item label="*邮箱">
          <el-input v-model="RestStForm.stEmail"/>
        </el-form-item>

        <el-form-item label="*手机号">
          <el-input v-model="RestStForm.stPhone"/>
        </el-form-item>
      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="RestStu = false">关闭窗口</el-button>
        <el-button type="primary" @click="setStu(RestStForm)">修改信息</el-button>
      </span>
      </template>
    </el-dialog>
    <!--添加比赛弹出窗口-->
    <el-dialog v-model="addGame" title="添加签到项目" width="500px">
      <el-form :model="form"
               :label-position="'right'">
        <el-form-item label="*项目名称">
          <el-input v-model="form.name"/>
        </el-form-item>

        <el-form-item label="*签到经度">
          <el-input v-model="form.longitude"/>
        </el-form-item>

        <el-form-item label="*签到纬度">
          <el-input v-model="form.latitude"/>
        </el-form-item>

        <el-form-item label="*签到范围(米)">
          <el-input v-model="form.area"/>
        </el-form-item>

      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="addGame = false">关闭窗口</el-button>
        <el-button type="primary" @click="setNewGame(form)">添加项目</el-button>
      </span>
      </template>
    </el-dialog>

    <!--    添加学生-->
    <el-dialog v-model="SingUpList_Find" title="添加参与项目的学生" width="800px">
      <el-upload
          v-model:file-list="fileList"
          class="upload-demo"
          :on-change="handleChange"
          :auto-upload="false"
      >
        <template #trigger>
          <el-button type="primary">一键添加</el-button>
        </template>
        &nbsp;
        <el-button type="primary" @click="uploadStu">上传</el-button>

        <template #tip>
          <div class="el-upload__tip">
            excel文件格式为：id,name,email，sex,phone
          </div>
        </template>
      </el-upload>


      <el-table :data="upload" height="400px">
        <el-table-column prop="stId" label="学生学号"></el-table-column>
        <el-table-column prop="stName" label="学生姓名"></el-table-column>
        <el-table-column prop="stSex" label="学生性别"></el-table-column>
        <el-table-column prop="stPhone" label="学生手机号"></el-table-column>
        <el-table-column prop="stEmail" label="学生邮箱"></el-table-column>
        <el-table-column fixed="right" label="操作" width="180">
          <template v-slot="scope">
            <el-tooltip effect="light" content="修改信息" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="openStSet(scope)"
              >
                <el-icon>
                  <Edit/>
                </el-icon>
              </el-button>
            </el-tooltip>

            <!--删除user信息按钮-->
            <el-tooltip effect="light" content="删除成员" placement="top">
              <el-button
                  link
                  type="primary"
                  size="default"
                  @click="StDelete(scope)"
              >
                <el-icon>
                  <Delete/>
                </el-icon>
              </el-button>
            </el-tooltip>

          </template>
        </el-table-column>
      </el-table>
    </el-dialog>

    <!--修改用户弹出窗口-->
    <el-dialog v-model="RestItem" title="添加签到项目" width="500px">
      <el-form :model="formSet"
               :label-position="'right'">

        <el-form-item label="*项目编号">
          <el-input v-model="formSet.id" disabled/>
        </el-form-item>

        <el-form-item label="*项目名称">
          <el-input v-model="formSet.name"/>
        </el-form-item>

        <el-form-item label="*签到经度">
          <el-input v-model="formSet.longitude"/>
        </el-form-item>

        <el-form-item label="*签到纬度">
          <el-input v-model="formSet.latitude"/>
        </el-form-item>

        <el-form-item label="*签到范围(米)">
          <el-input v-model="formSet.area"/>
        </el-form-item>

      </el-form>
      <template #footer>
      <span class="dialog-footer">
        <el-button @click="RestItem = false">关闭窗口</el-button>
        <el-button type="primary" @click="updataGame(formSet)">修改项目</el-button>
      </span>
      </template>
    </el-dialog>
  </div>
</template>


<script>


import {getCurrentInstance, onMounted} from "vue";
import {deleteItem} from "@/api/item/deleteItem";
import {addItem} from "@/api/item/addItem";
import {ItemList} from "@/api/item/getItemList";
import {updateItem} from "@/api/item/UpdataItem";
import {addStudent} from "@/api/student/addStudent";

export default {

  data() {
    return {
      addGame: false,
      //设置学生信息窗口
      RestStu: false,
      //修改学生信息表单
      RestStForm: {},
      currentItemId: '',

      //任务列表
      taskList: [],

      //学生信息列表
      upload: [],
      //添加用户窗口展示
      proID: '',
      SingUpList_Find: false,
      RestItem: false,
      setItemInfo: false,
      aaa: false,
      id: '',
      //添加项目表单
      form: {},
      //修改赛事表单
      formSet: {},
      //列表项
      tableData: [],

      game_find: []
    }
  },
  methods: {

    //上传学生
    uploadStu() {
      var up = {
        itemId: this.currentItemId,
        stuList: this.upload
      }
      addStudent(JSON.stringify(up)).then(res => {
        console.log(res)
        this.SingUpList_Find = false
      })
      this.upload = []
    },

    //删除指定行学生
    StDelete(scope) {
      this.upload.splice(scope.$index, 1)
    },

    //添加某项目的学生
    openStSet(scope) {
      console.log(scope)
      this.RestStu = true
      this.RestStForm = {
        stId: scope.row.stId,
        stName: scope.row.stName,
        stSex: scope.row.stSex,
        stEmail: scope.row.stEmail,
        stPhone: scope.row.stPhone,
        index: scope.$index
      }
      this.RestStu = false
    },

    //修改学生信息
    setStu($form) {
      console.log($form)
      this.upload[$form.index] = $form
    },




    //打开添加比赛的表单窗口
    openGameAdd() {
      this.addGame = true
    },

    //打开修改项目  列表一行
    openGameSet($row) {
      this.RestItem = true
      console.log($row)
      this.formSet.id = $row.id
      this.formSet.name = $row.name       // 项目名称
      this.formSet.longitude = $row.longitude // 签到经度
      this.formSet.latitude = $row.latitude    // 签到纬度
      this.formSet.area = $row.area      // 签到范围
    },

    //添加项目
    setNewGame($form) {
      const jsonForm = JSON.stringify($form);
      addItem(jsonForm)
          .then((res) => {
            console.log(res)
            this.addGame = false
            ItemList().then(res => {
              console.log(res)
              this.taskList = res.data.data
            })
          })
    },

    //更新项目
    updataGame($formSet) {
      const jsonForm = JSON.stringify($formSet);
      updateItem(jsonForm)
          .then((res) => {
            console.log(res)
            this.RestItem = false
            ItemList().then(res => {
              console.log(res)
              this.taskList = res.data.data
            })
          })
    },


    //删除项目
    Itemdelete($row) {
      console.log($row.id)
      deleteItem($row.id).then(res => {
        console.log(res)
        ItemList().then(res => {
          console.log(res)
          this.taskList = res.data.data
        })
      })
    },

    //打开已报名列表
    OpenSingUpList($row) {
      console.log($row.id)
      this.proId = $row.id
      this.currentItemId = $row.id
      this.SingUpList_Find = true
    },

  },


  setup() {
    const ins = getCurrentInstance();
    onMounted(() => {
      ItemList().then(res => {
        console.log(res)
        ins.data.taskList = res.data.data
      })
    });
  }
}

</script>

