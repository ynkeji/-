package org.sign.sign;

import org.junit.jupiter.api.Test;
import org.sign.sign.Bean.item.AbsenceList;
import org.sign.sign.Bean.student.UserLogin;
import org.sign.sign.Bean.student.student;
import org.sign.sign.Dao.ProjectDao;
import org.sign.sign.Dao.StudentMapper;
import org.sign.sign.Entity.Project;
import org.sign.sign.Entity.StudentEntity;
import org.sign.sign.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SpringBootTest
class SignApplicationTests {


    @Autowired
    private StudentService studentService;



    @Test
    void contextLoads() {
//        List<AbsenceList> list = studentService.GetAbsenceList(10,"").getData();
//
//        list.forEach(item -> {
//            System.out.println(item.toString());
//        });
    }



    public static boolean isWithinArea(double loginLatitude, double loginLongitude, double projectLatitude, double projectLongitude, double projectArea) {
        final int R = 6371000; // Radius of the earth in meters

        double latDistance = Math.toRadians(projectLatitude - loginLatitude);
        double lonDistance = Math.toRadians(projectLongitude - loginLongitude);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(loginLatitude)) * Math.cos(Math.toRadians(projectLatitude))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c; // convert to meters
        return distance <= projectArea;
    }


}
