package org.sign.sign.Dao;

import static org.junit.jupiter.api.Assertions.*;

class StudentMapperTest {
    @org.junit.jupiter.api.Test
    void getStudent() {

    }
}