package org.sign.sign.Interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.sign.sign.util.jwt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.HashMap;
import java.util.Map;

@Configurable
public class JwtInterceptor  implements HandlerInterceptor {
    @Autowired
    private StringRedisTemplate redisTemplate;


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if(request.getMethod().toUpperCase().equals("OPTIONS")){
            return true; // 通过所有OPTION请求
        } else {
            System.out.println("进入拦截器");
            String token = request.getHeader("token"); // 获取请求头中的token

            Map<String, Object> map = new HashMap<>();
            try {
                boolean verify = jwt.checkToken(token);
                if (verify) {
                    return true; // 通过验证
                } else {
                    System.out.println("未通过验证");
                    map.put("msg","未登录请求，请登陆后再试！");
                    String json = new ObjectMapper().writeValueAsString(map);
                    response.setContentType("application/json;charset=UTF-8");
                    response.getWriter().println(json);
                    return false; // 未通过验证
                }
            } catch (SignatureException e) {
                e.printStackTrace();
                map.put("msg", "无效签名");
            } catch (UnsupportedJwtException e) {
                e.printStackTrace();
                map.put("msg", "不支持的签名");
            } catch (ExpiredJwtException e) {
                e.printStackTrace();
                map.put("msg", "token过期");
            } catch (MalformedJwtException e) { // IllegalArgumentException
                e.printStackTrace();
                map.put("msg", "不支持的签名格式");
            } catch (Exception e) {
                e.printStackTrace();
                map.put("msg", "token无效");
            }
            map.put("state", false);
            // 将map转为json
            String json = new ObjectMapper().writeValueAsString(map);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().println(json);
            return false;
        }
    }
}
