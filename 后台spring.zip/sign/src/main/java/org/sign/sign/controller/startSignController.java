package org.sign.sign.controller;

import org.sign.sign.Service.ItemService;
import org.sign.sign.util.Response;
import org.sign.sign.util.jwt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.convert.ConversionService;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")//允许所有来源的请求跨域
@RequestMapping("/admin")
public class startSignController {

    @Autowired
    private ItemService itemService;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @RequestMapping(value = "/startSign", method = RequestMethod.GET)
    public Response<String> startSign(@RequestParam("itemId") int id, @RequestHeader("token") String token) {
        String managerId = jwt.getMemberIdByJwtToken(token);
        System.out.println(id + " "  + managerId);
        return itemService.startSign(id, managerId);
    }

    @RequestMapping(value = "/QRCode", method = RequestMethod.GET)
    public Response<String> QRCode(@RequestParam("itemId") int id, @RequestHeader("token") String token) {
        String manage = redisTemplate.opsForValue().get(id + "manager");
        if (manage == null || !manage.equals(jwt.getMemberIdByJwtToken(token))) {
            Response<String> response = new Response<>();
            response.setCode(201);
            response.setMsg("fail");
            response.setData("无权限");
            return response;
        }
        return itemService.QRCode(id);
    }

    @RequestMapping(value = "/endSign", method = RequestMethod.GET)
    public Response<String> endSign(@RequestParam("itemId") int id, @RequestHeader("token") String token) {
        String managerId = jwt.getMemberIdByJwtToken(token);
        return itemService.endSign(id, managerId);
    }
}
