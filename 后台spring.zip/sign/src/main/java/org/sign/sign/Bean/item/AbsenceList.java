package org.sign.sign.Bean.item;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AbsenceList {

    private String projectId;

    private String projectName;

    private String stName;

    private String stId;

    private  String absenceTime;

    private String longitude;

    private String latitude;

    private String reason;

    @Override
    public String toString() {
        return "AbsenceList{" +
                "projectId='" + projectId + '\'' +
                ", projectName='" + projectName + '\'' +
                ", stName='" + stName + '\'' +
                ", stId='" + stId + '\'' +
                ", absenceTime='" + absenceTime + '\'' +
                ", longitude='" + longitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", reason='" + reason + '\'' +
                '}';
    }
}
