package org.sign.sign.Bean.student;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Getter
@Setter
public class projectToStudent {

    // 项目id
    private int projectId;

    // 签到状态
    private String signed = "";

    // 迟到次数
    private String late = "";

    //请假状态
    private String absence = "";

    //请假原因
    private String reason = "";

    // 学生id
    private String stId;

    //学生名称
    private String name;

    //学生性别
    private String sex;

    //学生电话
    private String phone;

    //学生邮箱
    private String email;
    @DateTimeFormat(pattern = "yyyy-MM-dd-HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd-HH:mm:ss", timezone = "GMT")
    private Date signTime = null;

    private String longitude = "";

    private String latitude = "";

    //学生负责人
    private int manager;

}
