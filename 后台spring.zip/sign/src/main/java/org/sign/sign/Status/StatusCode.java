package org.sign.sign.Status;

public class StatusCode {

    public static final int Success = 200;

    public static final int Fail = 300;

    public static final int NotLogin = 10002;



}
