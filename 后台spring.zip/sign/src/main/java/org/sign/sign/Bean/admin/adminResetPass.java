package org.sign.sign.Bean.admin;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class adminResetPass {

    private String username;

    private String password;

    private String oldPassword;
}
