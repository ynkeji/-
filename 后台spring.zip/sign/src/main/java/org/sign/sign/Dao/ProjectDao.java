package org.sign.sign.Dao;


import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.sign.sign.Bean.item.AbsenceList;
import org.sign.sign.Bean.item.itemUpdata;
import org.sign.sign.Bean.item.signList;
import org.sign.sign.Entity.Project;
import org.sign.sign.Entity.ProjectList;
import org.sign.sign.Entity.ProjectView;

import java.util.List;

@Mapper
public interface ProjectDao {


    ///添加项目
    @Insert("insert into item(name,longitude,latitude,area,manager) values(#{name},#{longitude},#{latitude},#{area},#{manager})")
    int addProject(Project project);

    ///获取所有项目
    List<ProjectList> getProject(Integer id);

    ///更新项目
    @Update("update item set name = #{name},longitude = #{longitude},latitude = #{latitude},area = #{area}where id = #{id}")
    void updateProject(itemUpdata item);

    ///获取项目
    @Select("select * from item where id = #{id}")
    Project getProjectById(int id);

    ///删除项目
    @Update("delete from item where id = #{id}")
    void deleteProject(int id);

    List<ProjectView> ProjectView(int id);

    List<signList> getSignListByProjectId(int projectId);

    @Insert("insert into scheduled_task(task_key,task_desc,task_cron,init_start_flag,create_time,update_time) values(#{taskKey},#{taskDesc},#{taskCron},#{initStartFlag},#{createTime},#{updataTime})")
    int addScheduledTask(String taskKey, String taskDesc, String taskCron, int initStartFlag, String createTime, String updataTime);



    List<AbsenceList> getAbsenceList(int id);

}
