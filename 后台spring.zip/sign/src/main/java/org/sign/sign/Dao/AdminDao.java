package org.sign.sign.Dao;


import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;
import org.sign.sign.Bean.admin.adminRegister;
import org.sign.sign.Bean.admin.adminReSet;
import org.sign.sign.Bean.admin.adminUserInfo;
import org.sign.sign.Entity.admin;

@Mapper
public interface AdminDao {
    @Select("select * from admin where username = #{username}")
    admin getPass(String username);

    @Insert("insert into admin(username,password,phone,email) values(#{username},#{password},#{phone},#{email})")
    int SetUser(adminRegister register);

    @Select("select count(*) from admin where username = #{username}")
    int getUser(String username);

    @Update("update admin set username = #{username},phone = #{phone} where email = #{email}")
    int reset(adminReSet reset);

    @Update("update admin set password = #{password} where username=#{username}")
    int resetPass(String username,String password);

    @Select("SELECT username,phone,email FROM admin WHERE id = #{id}")
    adminUserInfo getUserInfo(Integer id);

}
