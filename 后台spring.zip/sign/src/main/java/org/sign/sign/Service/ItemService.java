package org.sign.sign.Service;

import org.sign.sign.Bean.item.itemUpdata;
import org.sign.sign.Bean.item.signList;
import org.sign.sign.Entity.Project;
import org.sign.sign.Entity.ProjectList;
import org.sign.sign.Entity.ProjectView;
import org.sign.sign.util.Response;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ItemService {

    public Response<String> addItem(Project project);

    public Response<List<ProjectList>> getItemList(int id);


    public Response<String> deleteItem(int id);

    public Response<List<ProjectView>> ItemView(int id);

    Response<String> updateItem(itemUpdata itemUpdata, int id);

    Response<List<signList>> getSignList(int projectId);

    Response<String> startSign(int id, String managerId);

    Response<String> QRCode(int id);

    Response<String> endSign(int id, String managerId);
}
