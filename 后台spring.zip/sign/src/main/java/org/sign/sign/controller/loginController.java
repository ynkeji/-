package org.sign.sign.controller;

import org.sign.sign.Bean.admin.*;
import org.sign.sign.Service.AdminService;
import org.sign.sign.util.Response;
import org.sign.sign.util.jwt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*")//允许所有来源的请求跨域
@RestController
@RequestMapping(value = "/admin")
public class loginController {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private AdminService adminService;

    //登录
    @RequestMapping(value = "/login")
    public Response<String> login(@RequestBody adminLogin login){

        return adminService.login(login);
    }


    //注册
    @RequestMapping(value = "/register")
    public Response<String> register(@RequestBody adminRegister login) {
        return adminService.register(login);
    }


    //信息修改
    @RequestMapping(value = "/reset")
    public Response<String> reset(@RequestBody adminReSet infor) {

        return adminService.reset(infor);
    }


    //修改密码
    @RequestMapping(value = "/resetPass")
    public Response<String> resetPass(@RequestBody adminResetPass pass) {
        return adminService.resetPass(pass);
    }


    @RequestMapping(value = "/userInfo", method = RequestMethod.GET)
    public Response<adminUserInfo> userInfo(@RequestHeader("token") String token) {
        String getMemberIdBy = jwt.getMemberIdByJwtToken(token);
        if (getMemberIdBy.isEmpty()) {
            Response<adminUserInfo> response = new Response<>();
            response.setCode(300);
            response.setMsg("请重新登录");
            response.setData(null);
            return response;
        }

        return adminService.adminUserInfo(Integer.parseInt(getMemberIdBy));
    }


}
