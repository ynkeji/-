package org.sign.sign.controller;


import org.sign.sign.Bean.admin.adminUserInfo;
import org.sign.sign.Bean.item.AbsenceList;
import org.sign.sign.Bean.student.UserLogin;
import org.sign.sign.Bean.student.UserToken;
import org.sign.sign.Bean.student.absence;
import org.sign.sign.Service.AdminService;
import org.sign.sign.Service.StudentService;
import org.sign.sign.util.Response;
import org.sign.sign.util.jwt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")//允许所有来源的请求跨域
@RestController
@RequestMapping(value = "/user")
public class userController {
    @Autowired
    private StudentService studentService;


    @RequestMapping(value = "/sign",method = RequestMethod.POST)
    public Response<String> sign(@RequestBody UserLogin login, @RequestHeader("token") String token){

        System.out.println("longitude" + login.getLongitude() + "  latitude" + login.getLatitude());
        return studentService.login(login,token);
    }

    @RequestMapping(value = "/getToken",method = RequestMethod.POST)
    public Response<String> getToken(@RequestBody UserToken userToken){
        return studentService.getToken(userToken);
    }


    ///学生请假api
    public Response<String> absence(@RequestBody absence absence, @RequestHeader("token") String token){
        return studentService.Absence(absence,token);
    }


    
}
