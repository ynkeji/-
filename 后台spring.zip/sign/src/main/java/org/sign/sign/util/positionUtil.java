package org.sign.sign.util;

import org.sign.sign.Bean.student.UserLogin;
import org.sign.sign.Bean.student.absence;
import org.sign.sign.Entity.Project;

public class positionUtil {

    public static boolean isWithinArea(UserLogin login, Project project) {
        return area(project, login.getLatitude(), login.getLongitude());
    }


    public static boolean isWithinArea(absence ab, Project project) {
        return area(project, ab.getLatitude(), ab.getLongitude());
    }

    private static boolean area(Project project, String latitude, String longitude) {
        final int R = 6371000; // Radius of the earth in meters
        double latDistance = Math.toRadians(Double.parseDouble(project.getLatitude()) - Double.parseDouble(latitude));
        double lonDistance = Math.toRadians(Double.parseDouble(project.getLongitude()) - Double.parseDouble(longitude));
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(Double.parseDouble(latitude))) * Math.cos(Math.toRadians(Double.parseDouble(project.getLatitude())))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c; // convert to meters
        return distance <= Double.parseDouble(project.getArea());
    }
}
