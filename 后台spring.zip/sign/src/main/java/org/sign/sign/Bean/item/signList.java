package org.sign.sign.Bean.item;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class signList {

        private String stId;

        private String stName;

        private String signed;

        private String late;

        private String absence;

        private String reason;

        private String signTime;

        private String longitude;

        private String latitude;

}
