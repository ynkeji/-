package org.sign.sign.Entity;

import lombok.Data;

@Data
public class admin {
    private int id;

    private String username;

    private String password;

    private String phone;

    private String email;
}
