package org.sign.sign.Bean.admin;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class adminRegister {

    private String username;

    private String password;

    private String phone;

    private String email;
}
