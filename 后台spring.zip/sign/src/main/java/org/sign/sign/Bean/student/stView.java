package org.sign.sign.Bean.student;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Data
public class stView {

    private String stEmail;
    private String stId;
    private String stName;
    private String stPhone;
    private String stSex;
}
