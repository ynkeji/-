package org.sign.sign.Service.impl;


import org.apache.commons.codec.digest.DigestUtils;
import org.sign.sign.Bean.item.AbsenceList;
import org.sign.sign.Bean.student.*;
import org.sign.sign.Dao.ProjectDao;
import org.sign.sign.Dao.StudentMapper;
import org.sign.sign.Entity.Project;
import org.sign.sign.Service.StudentService;
import org.sign.sign.util.Response;
import org.sign.sign.util.WeChatUtil;
import org.sign.sign.util.jwt;
import org.sign.sign.util.positionUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


@Service
public class studentImpl implements StudentService {

    @Autowired
    private StudentMapper studentMapper;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private ProjectDao projectDao;

    @Override
    public Response<String> addStudent(addStudent add, int id) {
        int itemId = (int) add.getItemId();
        List<projectToStudent> ps = new ArrayList<>();
        for (student student : add.getStuList()) {
            projectToStudent p = new projectToStudent();
            // 项目id
            System.out.println();
            p.setProjectId(itemId);
            // 学生id
            p.setStId(String.valueOf(student.getStId()));
            System.out.println(student.getStId());
            // 学生姓名
            p.setName(student.getStName());
            // 学生邮箱
            p.setEmail(student.getStEmail());
            // 学生电话
            p.setPhone(student.getStPhone());
            // 学生性别
            p.setSex(student.getStSex());
            // 负责人
            p.setManager(id);
            ps.add(p);
        }
        studentMapper.addStudent(ps);
        studentMapper.addProjectAs(ps);
        Response<String> response = new Response<>();
        response.setCode(200);
        response.setMsg("添加成功");
        response.setData(null);
        return response;
    }

    @Override
    public Response<List<stView>> getStudent(String id) {
        System.out.println(studentMapper.getStudentByManager(id));
        List<stView> students = studentMapper.getStudentByManager(String.valueOf(id));
        Response<List<stView>> response = new Response<>();
        response.setCode(200);
        response.setMsg("查询成功");
        response.setData(students);
        return response;
    }

    //完全删除学生
    @Override
    public Response<String> deleteStudent(String stId, int id) {
        if (studentMapper.checkStudent(stId, id) != 0 && studentMapper.checkStudent(stId, id) != 0) {
            studentMapper.deleteStudent(stId, id);
            int sum = studentMapper.deleteProjectAs(stId, id);
            Response<String> response = new Response<>();
            response.setCode(200);
            response.setMsg("删除成功");
            response.setData("成功删除" + sum + "条项目关联数据");
            return response;
        } else {
            Response<String> response = new Response<>();
            response.setCode(300);
            response.setMsg("删除失败");
            response.setData(null);
            return response;
        }
    }

    @Override
    public Response<String> updateStudent(student student, int id) {
        if (studentMapper.checkStudent(student.getStId(), id) == 1) {
            studentMapper.updateStudent(student, id);
            Response<String> response = new Response<>();
            response.setCode(200);
            response.setMsg("修改成功");
            response.setData(null);
            return response;
        } else {
            Response<String> response = new Response<>();
            response.setCode(300);
            response.setMsg("修改失败");
            response.setData(null);
            return response;
        }
    }

    @Override
    public Response<List<ProjectInfo>> getProjectInfo(String stId, int id) {
        List<ProjectInfo> projectInfo = studentMapper.getProjectInfo(stId, id);
        Response<List<ProjectInfo>> response = new Response<>();
        response.setCode(200);
        response.setMsg("查询成功");
        response.setData(projectInfo);
        return response;
    }

    @Override
    public Response<String> getToken(UserToken userToken) {
        Response<String> response = new Response<>();
        if (userToken.getWxCode().isEmpty() || userToken.getCode().isEmpty()) {
            response.setCode(300);
            response.setMsg("获取token失败");
            response.setData(null);
            return response;
        }
        String code = stringRedisTemplate.opsForValue().get(String.valueOf(userToken.getProjectId()));
        if (code == null) {
            response.setCode(300);
            response.setMsg("活动还没开始哦！");
            response.setData(null);
            return response;
        } else if (!code.equals(userToken.getCode())) {
            System.out.println(code);
            System.out.println(userToken.getCode());
            response.setCode(300);
            response.setMsg("二维码失效~");
            response.setData(null);
            return response;
        } else {
            String openId = WeChatUtil.getSessionKeyOrOpenId(userToken.getWxCode());
            System.out.println(openId);
            if (openId == null) {
                response.setCode(300);
                response.setMsg("您的输入有误");
                response.setData(null);
                return response;
            }
            String token = jwt.getJwtToken(userToken.getWxCode(), DigestUtils.md5Hex(openId));
            response.setCode(200);
            response.setMsg("success");
            response.setData("获取成功");
            response.setToken(token);
            return response;
        }
    }

    @Override
    public Response<String> login(UserLogin login, String token) {
        System.out.println("longitude" + login.getLongitude() + "  latitude" + login.getLatitude());
        Response<String> response = new Response<>();
        if (token == null) {
            response.setCode(300);
            response.setMsg("未扫码登录！");
            response.setData(null);
            return response;
        }
        String openId = jwt.getMemberNickNameByJwtToken(token);
        if (openId == null) {
            response.setCode(300);
            response.setMsg("未扫码登录！");
            response.setData(null);
            return response;
        }
        String stId = studentMapper.getStIdByOpenid(openId, login.getProjectId());
        if (stId == null) {
            Project project = projectDao.getProjectById(login.getProjectId());
            if (project == null) {
                response.setCode(300);
                response.setMsg("活动不存在");
                response.setData(null);
                return response;
            }
            System.out.println(login.getStId());
            int count  = studentMapper.getStudentById(login.getStId(), project.getId());
            if (count == 0) {
                response.setCode(300);
                System.out.println(stId);
                response.setMsg("学生不存在");
                response.setData(null);
                return response;
            }
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");
            String formatDateTime = now.format(formatter);
            response.setCode(200);
            String state = "";
            if (positionUtil.isWithinArea(login, project)) {
                response.setMsg("success");
                state = "已签到";
                response.setData("签到成功");
            } else {
                state = "范围外签到";
                response.setMsg("范围外签到");
                response.setData(null);
            }
            studentMapper.updateProjectAs(
                    state,
                    formatDateTime,
                    login.getLongitude(),
                    login.getLatitude(),
                    login.getStId(),
                    login.getProjectId(),
                    openId
            );
            return response;

        } else {
            response.setCode(300);
            response.setMsg("账号重复签到！");
            response.setData(null);
            return response;
        }
    }

    @Override
    public Response<String> Absence(absence absence,String token) {
        Response<String> response = new Response<>();
        if (token == null) {
            response.setCode(300);
            response.setMsg("未扫码登录！");
            response.setData(null);
            return response;
        }
        String openId = jwt.getMemberNickNameByJwtToken(token);
        if (openId == null) {
            response.setCode(300);
            response.setMsg("未扫码登录！");
            response.setData(null);
            return response;
        }

        int count  = studentMapper.getStudentById(absence.getStId(), absence.getProjectId());
        if (count == 0) {
            response.setCode(300);
            response.setMsg("学生不存在");
            response.setData(null);
            return response;
        }


        Project project = projectDao.getProjectById(absence.getProjectId());
        if (project == null) {
            response.setCode(300);
            response.setMsg("活动不存在");
            response.setData(null);
            return response;
        }

        count = studentMapper.checkAbsence(absence.getStId(), absence.getProjectId());

        if (count != 0) {
            response.setCode(300);
            response.setMsg("系统有正在处理的请假信息，请稍后再试！");
            response.setData(null);
            return response;
        }

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss");
        String formatDateTime = now.format(formatter);
        studentMapper.absence(
                formatDateTime,
                absence.getLongitude(),
                absence.getLatitude(),
                absence.getStId(),
                absence.getProjectId(),
                openId,
                absence.getReason()
        );
        response.setCode(200);
        response.setMsg("请假成功");
        response.setData(null);
        return response;
    }

    @Override
    public Response<List<AbsenceList>> GetAbsenceList(String token) {
        int manageId = Integer.parseInt(jwt.getMemberIdByJwtToken(token));
        if (manageId == 0) {
            Response<List<AbsenceList>> response = new Response<>();
            response.setCode(300);
            response.setMsg("未登录");
            response.setData(null);
            return response;
        }
        Response<List<AbsenceList>> response = new Response<>();
        List<AbsenceList> absences = projectDao.getAbsenceList(manageId);
        response.setCode(200);
        response.setMsg("查询成功");
        response.setData(absences);
        return response;
    }


}
