package org.sign.sign.controller;

import org.sign.sign.Bean.item.AbsenceList;
import org.sign.sign.Bean.item.ItemAdd;
import org.sign.sign.Bean.item.itemUpdata;
import org.sign.sign.Bean.item.signList;
import org.sign.sign.Entity.Project;
import org.sign.sign.Entity.ProjectList;
import org.sign.sign.Entity.ProjectView;
import org.sign.sign.Service.ItemService;
import org.sign.sign.Service.StudentService;
import org.sign.sign.util.Response;
import org.sign.sign.util.jwt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")//允许所有来源的请求跨域
@RestController
@RequestMapping(value = "/admin")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @Autowired
    private StudentService studentService;


    @RequestMapping(value = "/getProject", method = RequestMethod.GET)
    public Response<List<ProjectList>> getProjectList(@RequestHeader("token") String token){
        System.out.println(jwt.getMemberIdByJwtToken(token));
        return itemService.getItemList(Integer.parseInt(jwt.getMemberIdByJwtToken(token)));
    }


    @RequestMapping(value = "/addItem", method = RequestMethod.POST)
    public Response<String> addProject(@RequestBody ItemAdd itemAdd, @RequestHeader("token") String token){

        if (itemAdd.getName() == null || itemAdd.getLatitude() == null || itemAdd.getLongitude() == null || itemAdd.getArea() == null){
            Response<String> response = new Response<>();
            response.setCode(300);
            response.setMsg("参数错误");
            response.setData(null);
            return response;
        }
        Project project = new Project();
        project.setName(itemAdd.getName());
        project.setLatitude(itemAdd.getLatitude());
        project.setLongitude(itemAdd.getLongitude());
        project.setManager(Integer.parseInt(jwt.getMemberIdByJwtToken(token)));
        project.setArea(itemAdd.getArea());
        return itemService.addItem(project);
    }


    @RequestMapping(value = "/deleteItem", method = RequestMethod.GET)
    public Response<String> deleteProject(@RequestParam("id") int id){
        return itemService.deleteItem(id);
    }

    @RequestMapping(value = "/ItemView", method = RequestMethod.GET)
    public Response<List<ProjectView>> itemView(@RequestHeader("token") String token){
        int id = Integer.parseInt(jwt.getMemberIdByJwtToken(token));
        System.out.println(id);
        return itemService.ItemView(id);
    }

    @RequestMapping(value = "/updateItem", method = RequestMethod.POST)
    public Response<String> updateItem(@RequestBody itemUpdata itemUpdata, @RequestHeader("token") String token){
        int id = Integer.parseInt(jwt.getMemberIdByJwtToken(token));
        return itemService.updateItem(itemUpdata, id);
    }

    @RequestMapping(value = "/getSignList", method = RequestMethod.GET)
    public Response<List<signList>> getSignList(@RequestParam("projectId") int projectId){
        return itemService.getSignList(projectId);
    }


    ///学生请假列表api
    @RequestMapping(value = "/getAbsenceList",method = RequestMethod.GET)
    public Response<List<AbsenceList>> getAbsenceList( @RequestHeader("token") String token){
        return studentService.GetAbsenceList(token);
    }

}
