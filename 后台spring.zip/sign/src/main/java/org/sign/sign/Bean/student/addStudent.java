package org.sign.sign.Bean.student;


import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.*;
import java.util.List;
import com.fasterxml.jackson.annotation.*;
@lombok.Data
public class addStudent {
    private long itemId;
    private student[] stuList;
    private Object the01J0Kdbx1Zet9R9Qegwq31Tafb;

    @JsonProperty("itemId")
    public long getItemId() { return itemId; }
    @JsonProperty("itemId")
    public void setItemId(long value) { this.itemId = value; }

    @JsonProperty("stuList")
    public student[] getStuList() { return stuList; }
    @JsonProperty("stuList")
    public void setStuList(student[] value) { this.stuList = value; }

    @JsonProperty("01J0KDBX1ZET9R9QEGWQ31TAFB")
    public Object getThe01J0Kdbx1Zet9R9Qegwq31Tafb() { return the01J0Kdbx1Zet9R9Qegwq31Tafb; }
    @JsonProperty("01J0KDBX1ZET9R9QEGWQ31TAFB")
    public void setThe01J0Kdbx1Zet9R9Qegwq31Tafb(Object value) { this.the01J0Kdbx1Zet9R9Qegwq31Tafb = value; }
}
