package org.sign.sign.Bean.item;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Getter
@Setter
public class ItemAdd {

    private String name;

    private String longitude;

    private String latitude;

    private String area;

}
