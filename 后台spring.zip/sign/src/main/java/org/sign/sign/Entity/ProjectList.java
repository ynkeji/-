package org.sign.sign.Entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class ProjectList {
    private int id;
    private String name;
    private String longitude;
    private String latitude;
    private String area;
    private int manager;
    private int stidCount; // 新增字段
}