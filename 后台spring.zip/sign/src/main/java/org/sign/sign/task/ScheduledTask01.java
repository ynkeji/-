package org.sign.sign.task;
import org.sign.sign.Service.ScheduledTaskJob;
import org.sign.sign.util.JedisUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;

import java.util.Random;
import java.util.concurrent.TimeUnit;

@Component
public class ScheduledTask01  implements ScheduledTaskJob {
    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledTask01.class);
//    JedisUtil instance = JedisUtil.getInstance();
    private String id;

    public void SetId(String itd,StringRedisTemplate st) {
        id = itd;
        stringRedisTemplate = st;
//        stringRedisTemplate.afterPropertiesSet();
    }

//    @Autowired
    private  StringRedisTemplate stringRedisTemplate = null;

    @Override
    public void run() {
        if (stringRedisTemplate == null) {
            return;
        }
        String code = stringRedisTemplate.opsForValue().get(id);
        try{
            System.out.println(id);
            if (code == null) {
                stringRedisTemplate.opsForValue().set(id, generateCode(),30, TimeUnit.SECONDS);
            } else {
            stringRedisTemplate.delete(id);
            stringRedisTemplate.opsForValue().set(id, generateCode(),30, TimeUnit.SECONDS);
            }
        }catch (Exception e){
            e.printStackTrace();
            LOGGER.error("error" + id);
        }

    }

    public static String generateCode() {
        Random random = new Random();
        StringBuilder code = new StringBuilder();
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (int i = 0; i < 5; i++) {
            char c = chars.charAt(random.nextInt(chars.length()));
            code.append(c);
        }
        return code.toString();
    }
}
