package org.sign.sign.Service;

import org.sign.sign.Bean.admin.*;
import org.sign.sign.util.Response;
import org.springframework.stereotype.Service;


@Service
public interface AdminService {
    //登录
    Response<String> login(adminLogin login);

    //注册
    Response<String> register(adminRegister login);

    Response<String> reset(adminReSet login);

    Response<String> resetPass(adminResetPass infor);

    Response<adminUserInfo> adminUserInfo(Integer id);
}
