package org.sign.sign.Service.impl;

import cn.hutool.json.JSONObject;
import org.sign.sign.Bean.item.itemUpdata;
import org.sign.sign.Bean.item.signCode;
import org.sign.sign.Bean.item.signList;
import org.sign.sign.Dao.ProjectDao;
import org.sign.sign.Entity.Project;
import org.sign.sign.Entity.ProjectList;
import org.sign.sign.Entity.ProjectView;
import org.sign.sign.Service.ItemService;
import org.sign.sign.Service.ScheduledTaskService;
import org.sign.sign.Status.StatusCode;
import org.sign.sign.util.QRCodeUtil;
import org.sign.sign.util.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class ItemImpl implements ItemService {
    @Autowired
    private ProjectDao projectDao;

    @Autowired
    private ScheduledTaskService scheduledTaskService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public Response<String> addItem(Project project) {
        System.out.println("name" + project.getName() + "latitude" + project.getLatitude() + "longitude" + project.getLongitude() + "range" + project.getArea() + "manager" + project.getManager());
        projectDao.addProject(project);
        Response<String> response = new Response<>();
        response.setData("添加成功！");
        response.setMsg("success");
        response.setCode(200);
        return response;
    }

    @Override
    public Response<List<ProjectList>> getItemList(int id) {
        Response<List<ProjectList>> response = new Response<>();
        List<ProjectList> projectList = projectDao.getProject(id);
        response.setData(projectList);
        response.setMsg("success");
        response.setCode(200);
        return response;
    }

    @Override
    public Response<String> deleteItem(int id) {
        Project project = projectDao.getProjectById(id);
        if (project != null) {
            projectDao.deleteProject(id);
            scheduledTaskService.delete(id);
            Response<String> response = new Response<>();
            response.setData("删除成功！");
            response.setMsg("success");
            response.setCode(200);
            return response;
        } else {
            Response<String> response = new Response<>();
            response.setData("不存在该项目");
            response.setMsg("fail");
            response.setCode(201);
            return response;
        }
    }

    @Override
    public  Response<List<ProjectView>> ItemView(int id) {
        Response<List<ProjectView>> response = new Response<>();
        List<ProjectView> projectView = projectDao.ProjectView(id);
        response.setData(projectView);
        response.setMsg("success");
        response.setCode(200);
        return response;
    }

    @Override
    public Response<String> updateItem(itemUpdata itemUpdata, int id) {
        Response<String> response = new Response<>();
        Project project = projectDao.getProjectById(Integer.parseInt(itemUpdata.getId()));
        if (project != null) {
            if (project.getManager() == id) {
                projectDao.updateProject(itemUpdata);
                response.setData("更新成功");
                response.setMsg("success");
                response.setCode(200);
                return response;
            } else {
                response.setData("更新失败");
                response.setMsg("fail");
                response.setCode(300);
                return response;
            }
        } else {
            response.setData("不存在该项目");
            response.setMsg("fail");
            response.setCode(300);
            return response;
        }
    }

    @Override
    public Response<List<signList>> getSignList(int projectId) {
        Response<List<signList>> response = new Response<>();
        List<signList> signLists = projectDao.getSignListByProjectId(projectId);
        response.setData(signLists);
        response.setMsg("success");
        response.setCode(200);
        return response;
    }

    @Override
    public Response<String> startSign(int id, String managerId) {
        Project project = projectDao.getProjectById(id);
        if (project == null) {
            Response<String> response = new Response<>();
            response.setData("不存在该项目");
            response.setMsg("fail");
            response.setCode(300);
            return response;
        }
        if (project.getManager() != Integer.parseInt(managerId)) {
            Response<String> response = new Response<>();
            response.setData("无权限");
            response.setMsg("fail");
            response.setCode(300);
            return response;
        }
        if (scheduledTaskService.start(String.valueOf(id)))
        {
            stringRedisTemplate.opsForValue().set(id + "manager", managerId, 1000*60*60*24, TimeUnit.SECONDS);
            Response<String> response = new Response<>();
            response.setData("开始签到");
            response.setMsg("success");
            response.setCode(200);
            return response;
        } else if (scheduledTaskService.isStart(String.valueOf(id))) {
            stringRedisTemplate.opsForValue().set(id + "manager", managerId, 1000*60*60*24, TimeUnit.SECONDS);
            Response<String> response = new Response<>();
            response.setData("开始签到");
            response.setMsg("success");
            response.setCode(200);
            return response;
        } else
        {
            Response<String> response = new Response<>();
            response.setData("启动失败");
            response.setMsg("fail");
            response.setCode(300);
            return response;
        }
    }

    @Override
    public Response<String> QRCode(int id) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();//io流
        Response<String> response = new Response<>();
        try {
            String content = stringRedisTemplate.opsForValue().get(String.valueOf(id));//获取redis中的数据
            signCode sc = new signCode();
            sc.setCode(content);
            sc.setProjectId(String.valueOf(id));
            JSONObject  jsonObject = new JSONObject(sc);
            QRCodeUtil.createCodeToOutputStream(jsonObject.toString(), baos);
            byte[] bytes = baos.toByteArray();//转换成字节
            String png_base64 = Base64.getEncoder().encodeToString(bytes);//转换成base64串
            png_base64 = png_base64.replaceAll("\n", "").replaceAll("\r", "");//删除 \r\n
            response.setCode(StatusCode.Success);
            response.setMsg("生成二维码成功");
            response.setData(png_base64);
        } catch (Exception e) {
            response.setCode(StatusCode.Fail);
            response.setMsg("生成二维码失败");
        }
        return response;
    }

    @Override
    public Response<String> endSign(int id, String managerId) {
        String manager = stringRedisTemplate.opsForValue().get(id + "manager");
        if (manager == null || !manager.equals(managerId)) {
            Response<String> response = new Response<>();
            response.setCode(201);
            response.setMsg("fail");
            response.setData("无权限");
            return response;
        }
        if (scheduledTaskService.stop(String.valueOf(id))) {
            Response<String> response = new Response<>();
            response.setData("结束签到");
            response.setMsg("success");
            response.setCode(200);
            return response;
        } else {
            Response<String> response = new Response<>();
            response.setData("结束失败");
            response.setMsg("fail");
            response.setCode(300);
            return response;
        }
    }
}
