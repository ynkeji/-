package org.sign.sign.Dao;

import org.apache.ibatis.annotations.*;
import org.sign.sign.Bean.item.signList;
import org.sign.sign.Bean.student.*;
import org.sign.sign.Entity.StudentEntity;
import org.sign.sign.util.Response;

import java.util.Date;
import java.util.List;

@Mapper
public interface StudentMapper {

    void addStudent(List<projectToStudent> studentEntity);

    void addProjectAs(List<projectToStudent> sp);

    @Select("select stId as stId,stName as stName,stSex as stSex,stPhone as stPhone,stEmail as  stEmail from stTable where stManager = #{id}")
    List<stView> getStudentByManager(@Param("id") String id);

    @Select("SELECT count(*) FROM projectAs WHERE stId = #{stId}  AND projectId = #{projectId}")
    int getStudentById(@Param("stId") String stId, @Param("projectId") int projectId);

    //删除学生 全部删除
    @Delete("delete from stTable where stId = #{id} and stManager = #{manager}")
    int deleteStudent(@Param("id") String id, @Param("manager") int manager);

    //删除学生关联的项目
    @Delete("delete from projectAs where stId = #{stId} and managerId = #{manager}")
    int deleteProjectAs(@Param("stId") String stId, @Param("manager") int manager);

    @Select("select count(*) from stTable where stId = #{stId} and stManager = #{manager}")
    int checkStudent(@Param("stId") String stId, @Param("manager") int manager);

    @Select("select count(*) from projectAs where stId = #{stId} and managerId = #{manager}")
    int checkProjectAs(@Param("stId") String stId, @Param("manager") int manager);

    @Update("update stTable set stName = #{student.stName},stSex = #{student.stSex},stPhone = #{student.stPhone},stEmail = #{student.stEmail} where stId = #{student.stId} and stManager = #{manager}")
    int updateStudent(@Param("student") student student,@Param("manager") int manager);

   List<ProjectInfo> getProjectInfo(@Param("stId") String stId, @Param("managerId") int manager);

    @Update("UPDATE projectAs SET signed = #{state}, signTime = #{signTime}, longitude = #{longitude}, latitude = #{latitude},openid=#{openid} WHERE stId = #{stId} AND projectId = #{projectId}")
    int updateProjectAs(@Param("state") String state,@Param("signTime") String signTime, @Param("longitude") String longitude, @Param("latitude") String latitude, @Param("stId") String stId, @Param("projectId") int projectId,@Param("openid") String openid);

    @Insert("INSERT INTO absence (stId,projectId,reason,dateTime,longitude,latitude,openid) VALUES(#{stId},#{projectId},#{reason},#{signTime},#{longitude},#{latitude},#{openid})")
    int absence(@Param("signTime") String signTime, @Param("longitude") String longitude, @Param("latitude") String latitude, @Param("stId") String stId, @Param("projectId") int projectId,@Param("openid") String openid,@Param("reason") String reason);

    @Select("SELECT count(*) FROM absence WHERE stId = #{stId} AND projectId = #{projectId}")
    int checkAbsence(@Param("stId") String stId, @Param("projectId") int projectId);

    @Select("SELECT stId from projectAs WHERE openid = #{openId} and projectId = #{projectId}")
    String getStIdByOpenid(String openId,int projectId);
}
