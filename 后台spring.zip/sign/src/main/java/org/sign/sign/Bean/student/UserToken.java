package org.sign.sign.Bean.student;


import lombok.Getter;
import lombok.Setter;

///获取token
@Getter
@Setter
public class UserToken {

    private int projectId;

    private String code;

    private String wxCode;

}
