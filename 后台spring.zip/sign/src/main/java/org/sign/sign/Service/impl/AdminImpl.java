package org.sign.sign.Service.impl;

import org.sign.sign.Bean.admin.*;
import org.sign.sign.Entity.admin;
import org.sign.sign.Service.AdminService;
import org.sign.sign.Dao.AdminDao;
import org.sign.sign.util.Response;
import org.sign.sign.util.jwt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class AdminImpl implements AdminService {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;


    @Autowired
    private AdminDao adminDao;

    @Override
    public Response<String> login(adminLogin login) {
        // TODO Auto-generated method stub
        Response<String> response = new Response<>();
        admin ad = adminDao.getPass(login.getUsername());
        if (ad == null) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("账号或密码错误");
            return response;
        }
        if (login.getPassword().equals(ad.getPassword())) {
            String token = jwt.getJwtToken(String.valueOf(ad.getId()), ad.getUsername());
            response.setCode(200);
            response.setMsg("success");
            response.setToken(token);
            response.setData("登录成功");
        } else {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("账号或密码错误");
        }
        return response;
    }

    @Override
    public Response<String> register(adminRegister login) {
        Response<String> response = new Response<>();
        int count = adminDao.getUser(login.getUsername());
        //数据验证
        if (login.getUsername() == null || login.getPassword() == null || login.getPhone() == null || login.getEmail() == null) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("数据不能为空");
            return response;
        }
        if (!login.getEmail().matches(".*@.*")) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("邮箱格式错误");
            return response;
        }

        if (!login.getPhone().matches("1[3-9]\\d{9}")) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("手机号格式错误");
            return response;
        }

        if (count == 0) {
            adminDao.SetUser(login);
            response.setCode(200);
            response.setMsg("success");
            response.setData("注册成功");
        } else {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("用户名已存在");
        }

        return response;
    }

    @Override
    public Response<String> reset(adminReSet login) {
        Response<String> response = new Response<>();
        if (login.getEmail() == null || login.getUsername() == null || login.getPhone() == null) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("数据不能为空");
            return response;
        }
        if (!login.getEmail().matches(".*@.*")) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("邮箱格式错误");
            return response;
        }

        if (!login.getPhone().matches("1[3-9]\\d{9}")) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("手机号格式错误");
            return response;
        }

        int count = adminDao.reset(login);
        if (count == 1) {
            response.setCode(200);
            response.setMsg("success");
            response.setData("修改成功");
        } else {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("修改失败");
        }

        return response;
    }

    @Override
    public Response<String> resetPass(adminResetPass infor) {
        Response<String> response = new Response<>();
        if (infor.getOldPassword() == null || infor.getPassword() == null || infor.getUsername() == null) {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("数据不能为空");
            return response;
        }

        admin ad = adminDao.getPass(infor.getUsername());

        if (ad.getPassword().equals(infor.getOldPassword())) {
            adminDao.resetPass(ad.getUsername(),infor.getPassword());
            response.setCode(200);
            response.setMsg("success");
            response.setData("修改成功");
            return response;
        } else {
            response.setCode(300);
            response.setMsg("fail");
            response.setData("原密码错误");
            return response;
        }

    }

    @Override
    public Response<adminUserInfo> adminUserInfo(Integer id) {
        adminUserInfo adminUserInfo = adminDao.getUserInfo(id);
        Response<adminUserInfo> response = new Response<>();
        if (adminUserInfo != null) {
            response.setCode(200);
            response.setMsg("success");
            response.setData(adminUserInfo);
            return response;
        }
        return null;
    }


}
