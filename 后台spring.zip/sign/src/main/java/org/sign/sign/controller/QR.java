package org.sign.sign.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.sign.sign.Status.StatusCode;
import org.sign.sign.util.QRCodeUtil;
import org.sign.sign.util.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Base64;

@RestController
public class QR {

    @Autowired
    private StringRedisTemplate redisTemplate;

    //生成二维码并将其返回给前端调用者
    @RequestMapping(value = "/generate",method = RequestMethod.GET)
    public Response<String> generateV2(@RequestParam("st") String content, HttpServletResponse servletResponse) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();//io流
        System.out.println("wwwwwwwwwwwwwwwww");
        Response<String> response = new Response<String>();
        try {
            QRCodeUtil.createCodeToOutputStream(content, baos);
            byte[] bytes = baos.toByteArray();//转换成字节
            String png_base64 = Base64.getEncoder().encodeToString(bytes);//转换成base64串
            png_base64 = png_base64.replaceAll("\n", "").replaceAll("\r", "");//删除 \r\n
            response.setCode(StatusCode.Success);
            response.setMsg("生成二维码成功");
            response.setData(png_base64);
        } catch (Exception e) {
            response = new Response<String>();
            response.setCode(StatusCode.Fail);
            response.setMsg("生成二维码失败");
        }
        return response;
    }
}
