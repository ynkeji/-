package org.sign.sign.Bean.student;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ItemList {

    private String itemId;
    private String itemName;

}
