package org.sign.sign.Service;

import org.sign.sign.Bean.item.AbsenceList;
import org.sign.sign.Bean.student.*;
import org.sign.sign.util.Response;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface StudentService {

    Response<String> addStudent(addStudent add, int id);

    Response<List<stView>> getStudent(String  id);

    Response<String> deleteStudent(String stId, int id);

    Response<String> updateStudent(student student, int id);

    Response<List<ProjectInfo>> getProjectInfo(String stId, int id);

    Response<String> getToken(UserToken userToken);

    Response<String> login(UserLogin login, String token);

    Response<String> Absence(absence absence,String token);

    Response<List<AbsenceList>> GetAbsenceList(String token);
}
