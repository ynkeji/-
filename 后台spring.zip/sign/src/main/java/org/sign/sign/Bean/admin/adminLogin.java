package org.sign.sign.Bean.admin;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class adminLogin {

    private String username;

    private String password;

}
