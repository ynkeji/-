package org.sign.sign.controller;


import org.sign.sign.Bean.student.ProjectInfo;
import org.sign.sign.Bean.student.addStudent;
import org.sign.sign.Bean.student.stView;
import org.sign.sign.Bean.student.student;
import org.sign.sign.Service.StudentService;
import org.sign.sign.util.Response;
import org.sign.sign.util.jwt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")//允许所有来源的请求跨域
@RestController
@RequestMapping(value = "/admin")
public class studentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping(value = "/addStudent", method = RequestMethod.POST)
    public Response<String> addStudent(@RequestBody addStudent addStudent, @RequestHeader("token") String token){
        int id = Integer.parseInt(jwt.getMemberIdByJwtToken(token));
        return studentService.addStudent(addStudent,id);
    }

    @RequestMapping(value = "/getStudent", method = RequestMethod.GET)
    public Response<List<stView>> getStudent(@RequestHeader("token") String token){
        String id = jwt.getMemberIdByJwtToken(token);
        System.out.println(id);
        return studentService.getStudent(id);
    }

    @RequestMapping(value = "/deleteStudent", method = RequestMethod.GET)
    public Response<String> deleteStudent(@RequestParam("stId") String stId, @RequestHeader("token") String token) {
        int id = Integer.parseInt(jwt.getMemberIdByJwtToken(token));
        return studentService.deleteStudent(stId, id);

    }

    @RequestMapping(value = "/updateStudent", method = RequestMethod.POST)
    public Response<String> updateStudent(@RequestBody student student, @RequestHeader("token") String token) {
        int id = Integer.parseInt(jwt.getMemberIdByJwtToken(token));
        return studentService.updateStudent(student, id);
    }

    @RequestMapping(value = "/getProjectInfo", method = RequestMethod.GET)
    public Response<List<ProjectInfo>> getProjectInfo(@RequestParam("stId") String stId, @RequestHeader("token") String token){
        int id = Integer.parseInt(jwt.getMemberIdByJwtToken(token));
        return studentService.getProjectInfo(stId,id);
    }
}

