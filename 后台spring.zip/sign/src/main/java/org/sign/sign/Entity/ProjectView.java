package org.sign.sign.Entity;

import lombok.Data;

import java.util.Date;

@Data
public class ProjectView {

    private String name;

    private int id;

    private int sum;

    private int signCount;

    private int lateCount;

    private Date signTime;

    private String longitude;

    private String latitude;

    private  int absenceCount;

}
