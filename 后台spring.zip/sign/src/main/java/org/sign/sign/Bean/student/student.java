package org.sign.sign.Bean.student;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@lombok.Data
public class student {
    private String stEmail;
    private String stId;
    private String stName;
    private String stPhone;
    private String stSex;

    @JsonProperty("stEmail")
    public String getStEmail() {
        return stEmail;
    }
    @JsonProperty("stId")
    public String getStId() {
        return stId;
    }
    @JsonProperty("stName")
    public String getStName() {
        return stName;
    }
    @JsonProperty("stPhone")
    public String getStPhone() {
        return stPhone;
    }
    @JsonProperty("stSex")
    public String getStSex() {
        return stSex;
    }
    @JsonProperty("stEmail")
    public void setStEmail(String stEmail) {
        this.stEmail = stEmail;
    }
    @JsonProperty("stId")
    public void setStId(String stId) {
        this.stId = stId;
    }

    @JsonProperty("stName")
    public void setStName(String stName) {
        this.stName = stName;
    }

    @JsonProperty("stPhone")
    public void setStPhone(String stPhone) {
        this.stPhone = stPhone;
    }

    @JsonProperty("stSex")
    public void setStSex(String stSex) {
        this.stSex = stSex;
    }

}
