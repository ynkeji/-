package org.sign.sign.Entity;


import com.baomidou.mybatisplus.annotation.InterceptorIgnore;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import net.sf.jsqlparser.expression.DateTimeLiteralExpression;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@TableName("item")
public class Project {

    private int id;

    private String name;

    private String longitude;

    private String latitude;

    private String area;

    private int manager;
}
