package org.sign.sign.Bean.student;


import lombok.Getter;
import lombok.Setter;


///签到信息
@Getter
@Setter
public class UserLogin {

    private String stId;

    private String longitude;

    private String latitude;

    private int projectId;

}
