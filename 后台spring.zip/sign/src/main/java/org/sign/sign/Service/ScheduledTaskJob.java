package org.sign.sign.Service;

public interface ScheduledTaskJob extends Runnable {
}
