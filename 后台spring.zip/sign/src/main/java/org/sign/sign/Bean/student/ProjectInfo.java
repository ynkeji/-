package org.sign.sign.Bean.student;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
public class ProjectInfo {

    private int projectId;

    private String signed;

    private String late;

    private String absence;

    private String reason;

    private String latitude;

    private String longitude;

    private String signTime;

    private String name;

}