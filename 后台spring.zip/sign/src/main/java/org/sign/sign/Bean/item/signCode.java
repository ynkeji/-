package org.sign.sign.Bean.item;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class signCode {

    private String Code;

    private String projectId;

}
