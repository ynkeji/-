package org.sign.sign.Bean.student;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class absence {

    private String stId;

    private String reason;

    private String longitude;

    private String latitude;

    private int projectId;
}
