package org.sign.sign.Bean.admin;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class adminUserInfo {

    private String username;

    private String phone;

    private String email;

}
