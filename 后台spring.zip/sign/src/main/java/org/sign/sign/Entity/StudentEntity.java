package org.sign.sign.Entity;


import lombok.Data;

@Data
public class StudentEntity {

    private String stId;

    private String stName;

    private String stSex;

    private String stPhone;

    private String stEmail;

    private int stManager;

    private String openid;
}
